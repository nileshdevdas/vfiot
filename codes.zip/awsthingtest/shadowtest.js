var deviceModule = require("aws-iot-device-sdk").device;

var device = deviceModule({
    keyPath: './certs/b063b1945d-private.pem.key',
    certPath: './certs/b063b1945d-certificate.pem.crt',
    caPath: './certs/AmazonRootCA1.pem',
    clientId: '',
    host: 'a3s2j494p4e3v2-ats.iot.us-east-2.amazonaws.com',
    debug: false,
    port: '8883',
    protocol: 'mqtts',
    enableMetrics: true,
    rejectUnauthorized: false
});

device.on("connect", () => {
    console.log('Succesfully connected.....');
})

device.on("error", (err) => {
    console.error(err);
});

device.on("message", (topic, message) => {
    console.log("Check..............", message.toString())
});



device.subscribe("$aws/things/MyRPi/shadow/update/accepted");

device.subscribe("$aws/things/MyRPi/shadow/update/rejected");

device.subscribe("$aws/things/MyRPi/shadow/get/accepted");

device.subscribe("$aws/things/MyRPi/shadow/get/rejected");


setTimeout(() => {
    console.log("publishing...")
    device.publish("$aws/things/MyRPi/shadow/get", "")
}, 2000);


/*device.publish("$aws/things/MyRPi/shadow/update", JSON.stringify({
    "state": {
        "desired": {
            "color": "RED",
            "engine": "ON",
            "sequence": ['BLUE', 'RED', 'GREEN']
        }

    }
}))*/
