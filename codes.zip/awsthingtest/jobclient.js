var jobClient = require("aws-iot-device-sdk").jobs;

var jobs = jobClient({
    keyPath: './certs/b063b1945d-private.pem.key',
    certPath: './certs/b063b1945d-certificate.pem.crt',
    caPath: './certs/AmazonRootCA1.pem',
    clientId: '',
    host: 'a3s2j494p4e3v2-ats.iot.us-east-2.amazonaws.com',
    debug: true,
    port: '8883',
    protocol: 'mqtts'
})
jobs.on("connect", () => {
    console.log("connected....")
})
jobs.subscribeToJobs("lab1iot", "update", (err, job) => {
    console.log("job............................")
    job.succeeded({}, (err) => {
        console.log("done successded ", err);
    });
});
jobs.startJobNotifications('lab1iot', function (err) {
    console.log(err)
});