const jobsModule = require('aws-iot-device-sdk').jobs;
function processTest() {

    const jobs = jobsModule({
        keyPath: './certs/b063b1945d-private.pem.key',
        certPath: './certs/b063b1945d-certificate.pem.crt',
        caPath: './certs/AmazonRootCA1.pem',
        clientId: '',
        host: 'a3s2j494p4e3v2-ats.iot.us-east-2.amazonaws.com',
        debug: true,
        port: '8883',
        protocol: 'mqtts'
    });

    jobs
        .on('connect', function () {
            console.log('connect');
        });
    jobs
        .on('close', function () {
            console.log('close');
        });
    jobs
        .on('reconnect', function () {
            console.log('reconnect');
        });
    jobs
        .on('offline', function () {
            console.log('offline');
        });
    jobs
        .on('error', function (error) {
            console.log('error', error);
        });
    jobs
        .on('message', function (topic, payload) {
            console.log('message', topic, payload.toString());
        });

    jobs.subscribe('testTopic');
    jobs.subscribeToJobs('lab1iot', 'update', function (err, job) {
            job.inProgress({ operation: 'update', step: 'step 1 of customJob' }, function (err) {
                job.succeeded({ operation: 'update', step: 'finished all steps' }, function (err) { });
            });
    });

    jobs.subscribeToJobs('lab1iot', function (err, job) {
        if (isUndefined(err)) {
            console.log('default job handler invoked, jobId: ' + job.id.toString());
            job.failed({ operation: job.operation, errorCondition: 'not yet implemented' }, function (err) { });
        }
        else {
            console.error(err);
        }
    });

    jobs.startJobNotifications('lab1iot', function (err) {
        console.error(err);
    });
}

processTest();