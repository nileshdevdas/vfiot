
var deviceModule = require("aws-iot-device-sdk").device;
var device = deviceModule({
    keyPath: 'C:/awsthingtest/certs/b063b1945d-private.pem.key',
    certPath: './certs/b063b1945d-certificate.pem.crt',
    caPath: './certs/AmazonRootCA1.pem',
    clientId: '',
    host: 'a3s2j494p4e3v2-ats.iot.us-east-2.amazonaws.com',
    debug: true,
    protocol: 'mqtts',
});
device.on("connect", () => {
    console.log('Succesfully connected.....');
})
device.on("message", (topic, message) => {
    console.log("Message => ", JSON.parse(message.toString()).status)
});
device.subscribe("nilesh_topic_1");
device.publish("nilehs_topic_1", JSON.stringify({ "status": "success" }));
