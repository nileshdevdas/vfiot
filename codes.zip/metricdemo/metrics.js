var AWS = require("aws-sdk");
var cloudwatch = new AWS.CloudWatch({
    region: 'us-west-1'
});
var i = 20;
setInterval(function () {
    i = i + 1;
    cloudwatch.putMetricData({
        Namespace: 'nileshtempraturedata',
        MetricData: [{
            MetricName: 'temperature',
            Value: i,
            Unit: 'Count'
        }]
    }, function (err, result) {
        if (err) {
            console.log("Error Occured ", err);
        } else {
            console.log("Metrics Published ", result);
        }
    });
}, 5000)

