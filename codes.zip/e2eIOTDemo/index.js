var deviceModule = require("aws-iot-device-sdk").device;
var device = deviceModule({
    keyPath: './certs/0ac066d14d-private.pem.key',
    certPath: './certs/0ac066d14d-certificate.pem.crt',
    caPath: './certs/AmazonRootCA1.pem',
    clientId: '',
    host: 'a3s2j494p4e3v2-ats.iot.us-west-2.amazonaws.com',
    debug: true,
    protocol: 'mqtts',
});
device.on("connect", () => {
    console.log('Succesfully connected.....');
})
device.on("message", (topic, message) => {
    console.log("Message => ", JSON.parse(message.toString()).status)
});
var i = 0;
var temperature = 25
    
setInterval(() => {
    i = (i + 1)
    temperature = temperature + 1;
    var data = {
        "datetime": new Date(),
        "temperature": temperature,
        "location": "wtc",
        "uuid": i
    }
    device.publish("nilesh/airconditioner", JSON.stringify(data));
    console.log("published.....")
}, 5000); 
